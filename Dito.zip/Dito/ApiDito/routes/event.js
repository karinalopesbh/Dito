var express = require('express');
var router = express.Router();
var db = require('../db');

/*POST*/
router.post('/save', function(req, res) {

	var Event = db.Mongoose.model('events', db.EventSchema, 'events');
	var newevent = new Event({ 
				UserId: req.body.UserId, 
				Event: req.body.Event, 
				DateEvent: req.body.DateEvent});
    
	newevent.save(function (err) {
        	if (err) {
            		res.status(500).json({ error: err.message });
            		res.end();
            		return;
        	}
        	res.json(newevent);
        	res.end();
    	});

   	res.status(200).json('OK');
});

/*GET*/
router.get('/get', function(req, res) {
    var Event = db.Mongoose.model('events', db.EventSchema, 'events');
    Event.distinct("Event").lean().exec(function(e,docs){
       res.json(docs);
       res.end();
    });
});

module.exports = router;
