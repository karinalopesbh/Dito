var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/ApiDito');
 
var eventschema = new mongoose.Schema({
	UserId: String,
	Event: String,
	DateEvent: String
}, 
{ 
	collection: 'events' 
});
 
module.exports = { Mongoose: mongoose, EventSchema: eventschema }
